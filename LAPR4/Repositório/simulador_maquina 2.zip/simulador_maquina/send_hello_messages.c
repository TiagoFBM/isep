#include <strings.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <pthread.h>
#include "monitor_requests.h"
#define HELLO_REQUEST 0
#define NACK 151
#define ACK 150


void* send_hello_messages(void* argv){

    machineData *ptr = (machineData *)argv;
    int size;
    int err, sock;
    char buffer[BUF_SIZE];
    struct addrinfo req, *list;
    fd_set fdset;

    bzero((char *)&req, sizeof(req));

    // let getaddrinfo set the family depending on the supplied server address
    req.ai_family = AF_UNSPEC;
    req.ai_socktype = SOCK_STREAM;

    err = getaddrinfo(ptr->tcpIp, SERVER_PORT, &req, &list);
    if (err){
        printf("Failed to get server address, error: %s\n", gai_strerror(err));
        pthread_exit((void *)NULL);
    }

    sock = socket(list->ai_family, list->ai_socktype, list->ai_protocol);
    if (sock == -1){
        perror("Failed to open socket");
        freeaddrinfo(list);
        pthread_exit((void *)NULL);
    }

    if (connect(sock, (struct sockaddr *)list->ai_addr, list->ai_addrlen) == -1){
        perror("Failed connect TCP");
        freeaddrinfo(list);
        close(sock);
        pthread_exit((void *)NULL);
    }

    freeaddrinfo(list);

    printf("Connected to Server.\n");
   

    // code of hello request
    unsigned char code = HELLO_REQUEST;

    // machine id
    unsigned short id = ptr->idMachine;

    // divisão do id em bytes
    unsigned char idFirstByte =(unsigned)((id >> 8) & 0xff);
    unsigned char idSecondByte =  (unsigned)(id & 0xff);

    // size do hello request -> conteudo + \0
    size = 5;
    

    // guardar a informação no buffer
    snprintf(buffer, sizeof(buffer), "%c%c%c%c", 0, code, idFirstByte, idSecondByte);

    write(sock, buffer, size);

    printf("A Hello request has been sent to the server\n\n");

    //WAITING FOR THE ANSWER

    printf("Waiting for the server message: \n\n");

    FD_ZERO(&fdset);

    // monitorizar o socket
    FD_SET(sock, &fdset);

    if (select(sock + 1, &fdset, NULL, NULL, NULL) < 0)
    {
        printf("Select error\n");
        pthread_exit((void *)NULL);
    }   

    // le o conteudo do buffer

    read(sock, &buffer, sizeof(buffer));
    unsigned char receivedCode = (unsigned char)buffer[1];

    if (receivedCode == NACK){
        printf("The server responds with NACK\n");
        printf("The request has been refused and ignored.\n");
        ptr->lastAnswerFromSCM = receivedCode;
        ptr->hasStatus = 0;
        close(sock);
        pthread_exit((void *)NACK);
    }

    else{
        printf("The server responds with ACK\n");
        ptr->lastAnswerFromSCM = receivedCode;
        ptr->hasStatus = 0;
        ptr->tcpSock = sock;
    }

    pthread_exit((void *)ACK);

}