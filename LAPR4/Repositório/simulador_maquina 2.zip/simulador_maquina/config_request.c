#include <strings.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <pthread.h>
#include "monitor_requests.h"

void* config_request(void* argv){

    machineData *ptr = (machineData *)argv;

    struct sockaddr_storage from;
    struct addrinfo req, *list;
    int newSock, sock, err;
    unsigned int adl;
    char buffer[BUF_SIZE];
    fd_set fdset;
    char fileName[80];
    char sufixFileName[] = "_ConfigFile.txt";
    char cliIPtext[BUF_SIZE], cliPortText[BUF_SIZE];
    int i;
    int cont = 0;

    bzero((char *)&req,sizeof(req));
	// requesting a IPv6 local address will allow both IPv4 and IPv6 clients to use it
	req.ai_family = AF_INET;
	req.ai_socktype = SOCK_STREAM;
	req.ai_flags = AI_PASSIVE;      // local address

	err=getaddrinfo(NULL, SERVER_PORT , &req, &list);

	if(err) {
        	printf("Failed to get local address, error: %s\n",gai_strerror(err)); exit(1); }

	sock=socket(list->ai_family,list->ai_socktype,list->ai_protocol);
	if(sock==-1) {
        	perror("Failed to open socket"); freeaddrinfo(list); exit(1);}

	if(bind(sock,(struct sockaddr *)list->ai_addr, list->ai_addrlen)==-1) {
        	perror("Bind failed");close(sock);freeaddrinfo(list);exit(1);}

	freeaddrinfo(list);

	listen(sock,SOMAXCONN);

	puts("Accepting TCP connections (both over IPv6 or IPv4). Use CTRL+C to terminate the server");

	adl=sizeof(from);

    printf("Received config request\n");

    while (1){
        cont ++;
        newSock = accept(sock, (struct sockaddr *)&from, &adl); 

        getnameinfo((struct sockaddr *)&from,adl,cliIPtext,BUF_SIZE,cliPortText,BUF_SIZE,NI_NUMERICHOST|NI_NUMERICSERV);
        printf("New connection from node %s, port number %s\n", cliIPtext, cliPortText);
                	

        FD_ZERO(&fdset);

        // monitorizar o socket
        FD_SET(newSock, &fdset);

        if (select(newSock + 1, &fdset, NULL, NULL, NULL) < 0){
            printf("Select error\n");
            exit(1);
        }

        // le o conteudo do buffer
        read(newSock, &buffer, sizeof(buffer));

        printf("Estou aqui!\n");

        unsigned char receivedCode = (unsigned char)buffer[1];

        printf("Código recebido: %hhd\n", receivedCode);
        
        if (receivedCode == CONFIG_REQUEST_CODE){

            printf("Entrei no for do ficheiro\n");

            unsigned short machineID = ((unsigned char)buffer[MACHINE_ID_OFFSET] | (unsigned char)buffer[MACHINE_ID_OFFSET+1] << 8);
            printf("%hu = %hu\n", machineID, ptr->idMachine);
            if(machineID == ptr->idMachine){
                int dataSize = (buffer[DATA_SIZE_OFFSET] | buffer[DATA_SIZE_OFFSET+1] << 8) & 0xffff;
                
                char str[dataSize+1];

                for (i = 0; i < dataSize; i++){
                    str[i] = buffer[DATA_OFFSET + i];
                }
                
                snprintf(fileName, sizeof(fileName), "%hu%d%s", ptr->idMachine, cont, sufixFileName);
                printf("%s\n", fileName);
                FILE *fp = fopen(fileName,"w");

                fwrite(str,1,dataSize,fp);

                fclose(fp);

                buffer[1] = ACK_CODE;

            } else {
                char errorMsg[] = "The Machine ID in the Message doesn't match with the Machine ID.";
                int size = strlen(errorMsg);

                unsigned char lsb = (unsigned)size & 0xff;
                unsigned char msb = (unsigned)size >> 8;

                buffer[DATA_SIZE_OFFSET] = lsb;
                buffer[DATA_SIZE_OFFSET + 1] = msb;

                for (i = 0; i < size; i++){
                    buffer[DATA_OFFSET + i] = errorMsg[i];
                }

            }

            if(ptr->reset==1){
                pthread_cond_wait(&condReset,&mutex);
                printf("The config_request function has stopped.");
            }

            write(newSock, buffer, BUF_SIZE);
        }

        close(newSock);

    }

    close(sock);
    pthread_exit((void *)NULL);
}