#include <strings.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include "monitor_requests.h"

#define HELLO_REQUEST 0
#define MESSAGE_REQUEST 1
#define ACK 150
#define NACK 151

void *send_messages(void *argv)
{

    machineData *ptr = (machineData *)argv;

    int err, sock;
    char buffer[BUF_SIZE], msg[BUF_SIZE];
    struct addrinfo req, *list;
    fd_set fdset;
    struct timeval timeout;
    char fileName[50];
    int size,i;

    bzero((char *)&req, sizeof(req));

    // let getaddrinfo set the family depending on the supplied server address
    req.ai_family = AF_UNSPEC;
    req.ai_socktype = SOCK_STREAM;

    err = getaddrinfo(ptr->tcpIp, SERVER_PORT, &req, &list);
    if (err)
    {
        printf("Failed to get server address, error: %s\n", gai_strerror(err));
        exit(1);
    }
    sock = socket(list->ai_family, list->ai_socktype, list->ai_protocol);
    if (sock == -1)
    {
        perror("Failed to open socket");
        freeaddrinfo(list);
        exit(1);
    }
    if (connect(sock, (struct sockaddr *)list->ai_addr, list->ai_addrlen) == -1)
    {
        perror("Failed connect TCP");
        freeaddrinfo(list);
        close(sock);
        exit(1);
    }

    freeaddrinfo(list);

    printf("Connected to Server.\n");

    // version
    unsigned char version = 0;

    // code of hello request
    unsigned char code = HELLO_REQUEST;

    // machine id
    unsigned short id = ptr->idMachine;

    // divisão do id em bytes
    unsigned char idFirstByte =(unsigned)((id >> 8) & 0xff);
    unsigned char idSecondByte =  (unsigned)(id & 0xff);

    // size do hello request -> conteudo + \0
    size = 5;
    

    // guardar a informação no buffer
    snprintf(buffer, sizeof(buffer), "%c%c%c%c", 0, code, idFirstByte, idSecondByte);

    write(sock, buffer, size);

    printf("A Hello request has been sent to the server\n\n");

    //WAITING FOR THE ANSWER

    printf("Waiting for the server message: \n\n");

    FD_ZERO(&fdset);

    // monitorizar o socket
    FD_SET(sock, &fdset);

    if (select(sock + 1, &fdset, NULL, NULL, NULL) < 0)
    {
        printf("Select error\n");
        exit(1);
    }   

    // le o conteudo do buffer

    read(sock, &buffer, sizeof(buffer));
    unsigned char  receivedCode = (unsigned char)buffer[1];

    if (receivedCode == NACK){
        printf("The server responds with NACK\n");
        printf("The request has been refused and ignored.\n");
        ptr->lastAnswerFromSCM = receivedCode;
        ptr->hasStatus = 0;
        close(sock);
        exit(1);
    }

    else{
        printf("The server responds with ACK\n");
        ptr->lastAnswerFromSCM = receivedCode;
        ptr->hasStatus = 0;
        ptr->lastAnswerFromSCM = receivedCode;
    }

    FILE *fptr;

    strcpy(fileName, ptr->nameFile);

    fptr = fopen(fileName, "r");

    if (!fptr)
    {
        perror("Can't open file\n");
        exit(1);
    }

    i = 0;

    // Read line from file till end of file.
    while ((fgets(msg, sizeof(msg), fptr)) != NULL)
    {   
        

        code = MESSAGE_REQUEST;

        printf("Generating a message...\n\n");

        // sleep para simular o processamento da mensagem
        sleep(ptr->simulationTime);

        // 6 -> version (1 byte) + code (1 byte) + id (2 bytes) + datalength (2 bytes)
        size = 6 + strlen(msg) + 1;

        // transformar os dois bytes que representam o tamanho data length em dois bytes independentes
        
        unsigned char sizeFirstByte = (char)((size >> 8) & 0xff);
        unsigned char sizeSecondByte = (char)(size & 0xff);

        snprintf(buffer, sizeof(buffer), "%c%c%c%c%c%c%s", 0, code, idFirstByte, idSecondByte, sizeFirstByte, sizeSecondByte, msg);

        write(sock, buffer, size);

        //timeout
        timeout.tv_sec = 60;

        printf("The message %s was sent to the server\n\n", msg);

        // waiting for the server message
        FD_ZERO(&fdset);
        FD_SET(sock, &fdset);

        int time = select(sock + 1, &fdset, NULL, NULL, &timeout);

        if (time < 0){
            printf("Select error\n");
            exit(1);
        }
        int cont = 0;
        // Ocorreu um timeout. Tenta reconectar-se ao servidor
        while(time == 0){
            // Tenta reconectar-se 3 vezes (Pequena simulação) -> Servidor em baixo

            if(cont == 3){
                printf("The server is down.\n");
                close(sock);
                exit(1);
            }

            if(connect(sock,(struct sockaddr *)list->ai_addr, list->ai_addrlen)==106) {
                perror("Connection still established\n"); 
            }

            // tenta reconectar-se
            FD_ZERO(&fdset);
            FD_SET(sock, &fdset);
            time = select(sock+1, &fdset, NULL, NULL, &timeout);
            cont++;

        }

        // lê a resposta do server
        read(sock, &buffer, sizeof(buffer));

        char lastMessage[sizeof(buffer)] ;
        receivedCode = (unsigned char)buffer[1];

        if (receivedCode == NACK){
            ptr->lastAnswerFromSCM = receivedCode;
            if (sizeof(buffer) - 6 < 0){
                ptr->hasStatus = 0;
            }

            for (i = 6; i < sizeof(buffer); i++){
                lastMessage[i - 6] = buffer[i];
            }
            ptr->hasStatus = 1;
            strcpy(ptr->lastStatusReceived, lastMessage);
            printf("The server responds with ACK\n");
            printf("The request has been refused and ignored.\n");
            close(sock);
            exit(1);
        }   

        else{

            printf("The server responds with ACK\n");

            ptr->lastAnswerFromSCM = receivedCode;
        
            if (sizeof(buffer) - 6 < 0){
                ptr->hasStatus = 0;
            }

            for (i = 6; i < sizeof(buffer); i++){
                lastMessage[i - 6] = buffer[i];
            }
            
            
            ptr->hasStatus = 1;
            strcpy(ptr->lastStatusReceived, lastMessage);
        }

        puts(buffer);
    }
    pthread_exit((void *)NULL);
    close(sock);
    exit(0);
}
